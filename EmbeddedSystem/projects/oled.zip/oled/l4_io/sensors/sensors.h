#pragma once

#include <stdbool.h>

bool sensors__init(void);
